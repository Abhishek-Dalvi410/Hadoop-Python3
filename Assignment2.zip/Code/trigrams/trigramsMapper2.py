#!/usr/bin/python3

import sys
for line in sys.stdin:
    line=line.strip()
    print(1,"\t",line)
